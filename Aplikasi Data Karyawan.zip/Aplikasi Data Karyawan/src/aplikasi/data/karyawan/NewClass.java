/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aplikasi.data.karyawan;

import java.sql.ResultSet;
import java.sql.Statement;

/**
 *
 * @author Barindo Surya
 */
public class NewClass {
    public String stayPrint(){
        String stay = "";
        try{
            Statement stat = (Statement) Koneksi.koneksiDB().createStatement();
            String sql;
            ResultSet res;
            
            sql = "SELECT * FROM t_printer WHERE jenis_printer = 'Printer Dewasa'";
            res = stat.executeQuery(sql);
            if (res.next()) {
                stay = res.getString("nama_printer");
            }
            stat.close();
        }catch(Exception e){
            System.out.println("Ada masalah pada method stayprint");
        }
        return stay;
    }
    
   public String stayPrint1(){
        String stay = "";
        try{
            Statement stat = (Statement) Koneksi.koneksiDB().createStatement();
            String sql;
            ResultSet res;
            
            sql = "SELECT * FROM t_printer WHERE jenis_printer = 'Printer Bayi'";
            res = stat.executeQuery(sql);
            if (res.next()) {
                stay = res.getString("nama_printer");
            }
            stat.close();
        }catch(Exception e){
            System.out.println("Ada masalah pada method stayprint1");
        }
        return stay;
    }
   
   public String stayPrint2(){
        String stay = "";
        try{
            Statement stat = (Statement) Koneksi.koneksiDB().createStatement();
            String sql;
            ResultSet res;
            
            sql = "SELECT * FROM t_printer WHERE jenis_printer = 'Printer Label'";
            res = stat.executeQuery(sql);
            if (res.next()) {
                stay = res.getString("nama_printer");
            }
            stat.close();
        }catch(Exception e){
            System.out.println("Ada masalah pada method stayprint2");
        }
        return stay;
    }
   
//   public String stayPrint3(){
//        String stay = "";
//        try{
//            Statement stat = (Statement) Koneksi.koneksiDB().createStatement();
//            String sql;
//            ResultSet res;
//            
//            sql = "SELECT * FROM t_printer WHERE jenis_printer = 'Printer nih'";
//            res = stat.executeQuery(sql);
//            if (res.next()) {
//                stay = res.getString("nama_printer");
//            }
//            stat.close();
//        }catch(Exception e){
//            System.out.println("Ada masalah pada method stayprint3");
//        }
//        return stay;
//    }
//    
//   public String stayPrint4(){
//        String stay = "";
//        try{
//            Statement stat = (Statement) Koneksi.koneksiDB().createStatement();
//            String sql;
//            ResultSet res;
//            
//            sql = "SELECT * FROM t_printer WHERE jenis_printer = 'Printer nih'";
//            res = stat.executeQuery(sql);
//            if (res.next()) {
//                stay = res.getString("nama_printer");
//            }
//            stat.close();
//        }catch(Exception e){
//            System.out.println("Ada masalah pada method stayprint4");
//        }
//        return stay;
//    }
   String[] aray = {stayPrint(),stayPrint1(),stayPrint2()};
//   String[] aray = {stayPrint(),stayPrint1(),stayPrint2(),stayPrint3(),stayPrint4()};
   
}
