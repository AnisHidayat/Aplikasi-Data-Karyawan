/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aplikasi.data.karyawan;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.HeadlessException;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.net.InetAddress;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.imageio.ImageIO;
import javax.print.Doc;
import javax.print.DocFlavor;
import javax.print.DocPrintJob;
import javax.print.PrintService;
import javax.print.PrintServiceLookup;
import javax.print.SimpleDoc;
import javax.print.attribute.HashAttributeSet;
import javax.print.attribute.standard.PrinterName;
import javax.swing.JOptionPane;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.text.AttributeSet;
//import net.proteanit.sql.DbUtils;

/**
 *
 * @author Barindo Surya
 */
public class InputData extends javax.swing.JFrame {
    public boolean databaru;
    PreparedStatement stm;
    Statement st;
    ResultSet rs;
    
    public String idKaryawan, nik, nama, jk, jabatan, noHp, alamat;
    //public int idKaryawan, nik;
    
    public String getNama(){
        return nama;
    }
    
    public String getJk(){
        return jk;
    }
    
    public String getJabatan(){
        return jabatan;
    }
    
    public String getAlamat(){
        return alamat;
    }
    
    
//    public int getId(){
//        return idKaryawan;
//    }
//    
//    public int getNik(){
//        return nik;
//    }
    public String getId(){
        return idKaryawan;
    }
    
    public String getNik(){
        return nik;
    }
    
    private String getDefaultPrinter(){
        String defaultPrinter = "default";
        try{
            defaultPrinter = PrintServiceLookup.lookupDefaultPrintService().getName();
            if (defaultPrinter.indexOf("\\\\") == -1) {
                String[] newPrinter = defaultPrinter.split("_");
                defaultPrinter = newPrinter.length == 2 ? "\\\\" + newPrinter[0] + "\\" + newPrinter[1] : "\\\\" + this.getLocalIp() + "\\" + defaultPrinter;
            }
        }catch(Exception e){
            defaultPrinter = "\\\\" + this.getLocalIp() + "\\" + defaultPrinter;
        }
        return defaultPrinter;
    }
    
    private String getLocalIp(){
        String ipStr = "127.0.0.1";
        try{
            InetAddress ip = InetAddress.getLocalHost();
        }catch(Exception e){
            e.printStackTrace();
        }return ipStr;
    }
    
//    public void itemTerpilih(){
//        try{
//            txt_id_karyawan.setText(idKaryawan);
//            txt_nama.setText(nama);
//            txt_nik.setText(nik);
//            txt_.setText(jk);
//        }catch(Exception e){
//            
//        }
//    }
    
    public static String bacaFile(String bacaFile){
        BufferedReader br = null;
        String stringHasil = "";
        try{
            String currentLine;
            br = new BufferedReader(new FileReader (bacaFile));
            while ((currentLine = br.readLine()) != null){
                stringHasil = stringHasil + currentLine + "\n";
            }
        }catch(Exception e){
            System.out.println("Gagal bca file" + bacaFile);
            e.printStackTrace();
        }finally{
            try{
                if (br != null) {
                    br.close();
                }
            }catch(IOException ioe){
                ioe.printStackTrace();
            }
        }return stringHasil;
    }
         
    boolean coba;
    
    Thread thread = new Thread(){
        public void run(){
            try{
                while(coba == true){
                    
                }
            }catch(Exception e){
                
            }
        }
    };
    
    public void cetakGelang(String nama_printer, String gelang){
        System.out.println("test print");
        try{
            PrintService psZebra = null;
            String printerName = nama_printer;
            javax.print.attribute.AttributeSet atribut = new HashAttributeSet();
            DocFlavor flavor = DocFlavor.BYTE_ARRAY.AUTOSENSE;
            atribut.add(new PrinterName(printerName, null));
            PrintService[] services = PrintServiceLookup.lookupPrintServices(flavor, atribut);
            for (int i = 0; i < services.length; i++) {
                if (printerName.equalsIgnoreCase(services[i].getName()) == true) {
                    psZebra = services[i];
                }
            }
            if (psZebra == null) {
                System.out.println("Printer Zebra tidak ditemukan.");
                JOptionPane.showMessageDialog(null, "Silahkan klik tombol 'Setting Printer' dulu bos");
                return;
            }
            System.out.println("Printer ditemukan" + printerName);
            DocPrintJob job = psZebra.createPrintJob();
            
//            String dokumen = "C:/Users/Public/Desktop/Langkah menyembunyikan file encrypt dan decrypt.docx";
//         
//            String code="1323";
//            BufferedImage img=new
//            BufferedImage(100,100,BufferedImage.TYPE_INT_RGB);
//            Graphics g=img.getGraphics();
//            g.setColor(Color.BLACK);
//            g.drawString(code,5,5);
//            ByteArrayOutputStream outstream=new ByteArrayOutputStream();
//            ImageIO.write( img, "jpg", outstream);
//            byte[] buf=outstream.toByteArray();
//            String value=new String(buf);
        Doc doc = new SimpleDoc(gelang.getBytes(), flavor, null);
            job.print(doc, null);
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
    public String nm_printer = "";
    public String gelang;
    public void isiKolom(String sIdKaryawan, String sNama, String sNik, String sJabatan, String sNoHp, String sAlamat){
        idKaryawan = sIdKaryawan;
        nama = sNama;
        nik = sNik;
        //jk = sJk;
        jabatan = sJabatan;
        noHp = sNoHp;
        alamat = sAlamat;
    }
    
/*    batas coding batas coding batas coding  */
    
    /**
     * Creates new form InputData
     */
    public InputData() {
        initComponents();
        GetData(); // tampilkan ke grid
        databaru=true;
        txt_id_karyawan.setText("");
        txt_nik.setText("");
        txt_nama.setText("");
        rdo_lakilaki.setSelected(false);
        rdo_perempuan.setSelected(false);
        cbo_jabatan.setSelectedItem(null);
        txt_nohp.setText("");
        txt_alamat.setText("");
    }
    
    private void GetData(){ // menampilkan data dari database

    DefaultTableModel model = new DefaultTableModel();
        model.addColumn("ID Pemain");
        model.addColumn("Nama");
        model.addColumn("NIP");
        model.addColumn("Jenis Kelamin");
        model.addColumn("Posisi");
        model.addColumn("No. HP");
        model.addColumn("Alamat");
        try{
            String sql = "SELECT * FROM t_karyawan";            
            Koneksi conn = new Koneksi();
            Connection getkoneksi = conn.koneksiDB();
            if(getkoneksi==null){
                JOptionPane.showMessageDialog(null, "Koneksi gagal ! periksa server");
            }
            st = getkoneksi.createStatement();
            rs = st.executeQuery(sql);
            //menampilkan ke table
            while(rs.next()){
             model.addRow(new Object[]{rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(7)});
            }
            tbl_karyawan.setModel(model);
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }


    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        btn_exit = new javax.swing.JButton();
        btn_clear = new javax.swing.JButton();
        btn_hapus = new javax.swing.JButton();
        btn_save = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        txt_alamat = new javax.swing.JTextField();
        txt_nohp = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        cbo_jabatan = new javax.swing.JComboBox<>();
        jLabel5 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        rdo_lakilaki = new javax.swing.JRadioButton();
        rdo_perempuan = new javax.swing.JRadioButton();
        txt_nik = new javax.swing.JTextField();
        txt_nama = new javax.swing.JTextField();
        txt_id_karyawan = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbl_karyawan = new javax.swing.JTable();
        jLabel8 = new javax.swing.JLabel();
        btn_cetak = new javax.swing.JButton();
        btn_pilih_printer = new javax.swing.JButton();

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Aplikasi Data Karyawan");
        setBackground(new java.awt.Color(0, 153, 153));

        jPanel2.setBackground(new java.awt.Color(0, 153, 102));

        btn_exit.setBackground(new java.awt.Color(255, 255, 255));
        btn_exit.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        btn_exit.setForeground(new java.awt.Color(0, 153, 102));
        btn_exit.setText("Exit");
        btn_exit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_exitActionPerformed(evt);
            }
        });

        btn_clear.setBackground(new java.awt.Color(255, 255, 255));
        btn_clear.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        btn_clear.setForeground(new java.awt.Color(0, 153, 102));
        btn_clear.setText("Clear");
        btn_clear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_clearActionPerformed(evt);
            }
        });

        btn_hapus.setBackground(new java.awt.Color(255, 255, 255));
        btn_hapus.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        btn_hapus.setForeground(new java.awt.Color(0, 153, 102));
        btn_hapus.setText("Delete");
        btn_hapus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_hapusActionPerformed(evt);
            }
        });

        btn_save.setBackground(new java.awt.Color(255, 255, 255));
        btn_save.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        btn_save.setForeground(new java.awt.Color(0, 153, 102));
        btn_save.setText("Save");
        btn_save.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_saveActionPerformed(evt);
            }
        });
        btn_save.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                btn_saveKeyPressed(evt);
            }
        });

        jLabel7.setFont(new java.awt.Font("Lucida Bright", 0, 12)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Alamat");

        txt_alamat.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txt_alamatKeyPressed(evt);
            }
        });

        txt_nohp.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txt_nohpKeyPressed(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("Lucida Bright", 0, 12)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("No. HP");

        cbo_jabatan.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Manajer", "Striker", "Midfielder", "Left Winger", "Right Winger", "Center Back", "Wing Back", "Goal Keeper", "Tim Medis" }));

        jLabel5.setFont(new java.awt.Font("Lucida Bright", 0, 12)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Posisi");

        jLabel4.setFont(new java.awt.Font("Lucida Bright", 0, 12)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Jenis Kelamin");

        buttonGroup1.add(rdo_lakilaki);
        rdo_lakilaki.setFont(new java.awt.Font("Lucida Bright", 0, 12)); // NOI18N
        rdo_lakilaki.setSelected(true);
        rdo_lakilaki.setText("Laki - laki");

        buttonGroup1.add(rdo_perempuan);
        rdo_perempuan.setFont(new java.awt.Font("Lucida Bright", 0, 12)); // NOI18N
        rdo_perempuan.setText("Perempuan");

        txt_nama.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txt_namaKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txt_namaKeyTyped(evt);
            }
        });

        txt_id_karyawan.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txt_id_karyawanKeyPressed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Lucida Bright", 0, 12)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("ID Pemain");

        jLabel2.setFont(new java.awt.Font("Lucida Bright", 0, 12)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Nama");

        jLabel3.setFont(new java.awt.Font("Lucida Bright", 0, 12)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("NIP");

        tbl_karyawan.setBackground(new java.awt.Color(0, 153, 0));
        tbl_karyawan.setForeground(new java.awt.Color(255, 255, 255));
        tbl_karyawan.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tbl_karyawan.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbl_karyawanMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tbl_karyawan);

        jLabel8.setFont(new java.awt.Font("Times New Roman", 1, 16)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(204, 0, 0));
        jLabel8.setText("DAFTAR PEMAIN DAN STAFF LIVERPOOL FC");

        btn_cetak.setBackground(new java.awt.Color(255, 255, 255));
        btn_cetak.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        btn_cetak.setForeground(new java.awt.Color(0, 153, 102));
        btn_cetak.setText("Cetak");
        btn_cetak.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_cetakActionPerformed(evt);
            }
        });

        btn_pilih_printer.setBackground(new java.awt.Color(255, 255, 255));
        btn_pilih_printer.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        btn_pilih_printer.setForeground(new java.awt.Color(0, 153, 102));
        btn_pilih_printer.setText("Pilih Printer");
        btn_pilih_printer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_pilih_printerActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(309, 309, 309)
                        .addComponent(jLabel8)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel3)
                                    .addComponent(jLabel2)
                                    .addComponent(jLabel1))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txt_nik, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 236, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txt_nama, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 236, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txt_id_karyawan, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 236, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addComponent(jLabel5)
                                        .addGap(44, 44, 44))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                                        .addComponent(jLabel4)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)))
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addComponent(rdo_lakilaki)
                                        .addGap(18, 18, 18)
                                        .addComponent(rdo_perempuan))
                                    .addComponent(cbo_jabatan, javax.swing.GroupLayout.PREFERRED_SIZE, 139, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(btn_save, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(btn_hapus)
                                .addGap(18, 18, 18)
                                .addComponent(btn_clear)
                                .addGap(18, 18, 18)
                                .addComponent(btn_exit))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel7)
                                    .addComponent(jLabel6))
                                .addGap(49, 49, 49)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(txt_alamat)
                                    .addComponent(txt_nohp, javax.swing.GroupLayout.PREFERRED_SIZE, 236, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(btn_cetak)
                                .addGap(18, 18, 18)
                                .addComponent(btn_pilih_printer)
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 538, Short.MAX_VALUE))))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addComponent(jLabel8)
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 302, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel1)
                            .addComponent(txt_id_karyawan, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(txt_nama, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txt_nik, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(rdo_lakilaki)
                            .addComponent(rdo_perempuan)
                            .addComponent(jLabel4))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(cbo_jabatan, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel5))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel6)
                            .addComponent(txt_nohp, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel7)
                            .addComponent(txt_alamat, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btn_exit)
                            .addComponent(btn_clear)
                            .addComponent(btn_hapus)
                            .addComponent(btn_save))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_cetak)
                    .addComponent(btn_pilih_printer))
                .addContainerGap(19, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btn_saveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_saveActionPerformed
        // TODO add your handling code here:
        boolean valid = true;
        if (databaru == true) { // prosess simpan atau edit
            if (txt_id_karyawan.getText().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Harap isi kolom ID karyawan");
                valid = false;
                txt_id_karyawan.requestFocusInWindow();
            }else if (txt_nama.getText().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Harap isi kolom Nama");
                valid = false;
                txt_nama.requestFocusInWindow();
            }else if (txt_nik.getText().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Harap isi kolom NIK");
                valid = false;
                txt_nik.requestFocusInWindow();
            }else if (cbo_jabatan.getSelectedItem() == null) {
                JOptionPane.showMessageDialog(null, "Harap pilih bagian Posisi");
                valid = false;
                cbo_jabatan.requestFocusInWindow();
            }else if (txt_alamat.getText().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Harap isi kolom Alamat");
                valid = false;
                txt_alamat.requestFocusInWindow();
            }
            
            try {
                String jk = "";
                if (rdo_lakilaki.isSelected()){
                    jk ="Laki - laki";
                }else{
                    jk = "Perempuan";
                }
                String sql = "insert into t_karyawan values('"+txt_id_karyawan.getText()+"','"+txt_nama.getText()+"', '"+txt_nik.getText()+"', '"+jk+"', '"+cbo_jabatan.getSelectedItem()+"', '"+txt_nohp.getText()+"', '"+txt_alamat.getText()+"')";
                java.sql.Connection conn = (java.sql.Connection)aplikasi.data.karyawan.Koneksi.koneksiDB();
                java.sql.PreparedStatement pst = conn.prepareStatement(sql);
                pst.execute();

                JOptionPane.showMessageDialog(null, "Data berhasil disimpan");
            } catch (SQLException | HeadlessException e) {
                JOptionPane.showMessageDialog(null, e);
            }
        } else {
            try {
                String jk = "";
                if (rdo_lakilaki.isSelected()){
                    jk ="Laki - laki";
                }else{
                    jk = "Perempuan";
                }
                String sql = "update t_karyawan SET nama_karyawan='"+txt_nama.getText()+"', nik='"+txt_nik.getText()+"', j_kelamin='"+jk+"',jabatan='"+cbo_jabatan.getSelectedItem()+"',no_telphone='"+txt_nohp.getText()+"',alamat='"+txt_alamat.getText()+"' where id_karyawan='"+txt_id_karyawan.getText()+"'";
                java.sql.Connection conn = (java.sql.Connection)aplikasi.data.karyawan.Koneksi.koneksiDB();
                java.sql.PreparedStatement pst = conn.prepareStatement(sql);
                pst.execute();
                JOptionPane.showMessageDialog(null, "Data berhasil diperbarui");
            } catch (SQLException | HeadlessException e) {
                JOptionPane.showMessageDialog(null, e);
            }
        }
        GetData();
    
        databaru=true;
        // mengosongkan textbox
        txt_id_karyawan.setText("");
        txt_nik.setText("");
        txt_nama.setText("");
        rdo_lakilaki.setSelected(false);
        rdo_perempuan.setSelected(false);
        cbo_jabatan.setSelectedItem(null);
        txt_nohp.setText("");
        txt_alamat.setText("");

    }//GEN-LAST:event_btn_saveActionPerformed

    private void btn_hapusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_hapusActionPerformed
        // TODO add your handling code here:
        try { // hapus data
            String sql ="delete from t_karyawan where id_karyawan='"+txt_id_karyawan.getText()+"'";
            java.sql.Connection conn = (java.sql.Connection)aplikasi.data.karyawan.Koneksi.koneksiDB();
            java.sql.PreparedStatement pst = conn.prepareStatement(sql);
            pst.execute();
            JOptionPane.showMessageDialog(null, "Data akan dihapus?");
            databaru=true;
            txt_id_karyawan.setText("");
            txt_nik.setText("");
            txt_nama.setText("");
            rdo_lakilaki.setSelected(false);
            rdo_perempuan.setSelected(false);
            cbo_jabatan.setSelectedItem(null);
            txt_nohp.setText("");
            txt_alamat.setText("");
         } catch (SQLException | HeadlessException e) {
        
         }
         GetData();
    }//GEN-LAST:event_btn_hapusActionPerformed

    private void tbl_karyawanMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbl_karyawanMouseClicked
        // TODO add your handling code here:
    databaru = false; // menampilkan data ke textboxt
        try {
        int row =tbl_karyawan.getSelectedRow();
        String tabel_klik=(tbl_karyawan.getModel().getValueAt(row,0).toString());
        java.sql.Connection conn = (java.sql.Connection)aplikasi.data.karyawan.Koneksi.koneksiDB();
        java.sql.Statement stm = conn.createStatement();
        java.sql.ResultSet sql = stm.executeQuery("select * from t_karyawan where id_karyawan='"+tabel_klik+"'");
            if(sql.next()){
                String id = sql.getString("id_karyawan");
                txt_id_karyawan.setText(id);
                String nama = sql.getString("nama_karyawan");
                txt_nama.setText(nama);
                String nik = sql.getString("nik");
                txt_nik.setText(nik);
                
                String jk = sql.getString("j_kelamin");
                    if (jk.equals("Laki - laki")) {
                        rdo_lakilaki.setSelected(true);
                    } else {
                        rdo_perempuan.setSelected(true);
                    }
                String jabatan = sql.getString("jabatan");
                cbo_jabatan.setSelectedItem(jabatan);
                String no_telp = sql.getString("no_telphone");
                txt_nohp.setText(no_telp);
                String alamat = sql.getString("alamat");
                txt_alamat.setText(alamat);
            }
        } catch (Exception e) {
               
        }
    }//GEN-LAST:event_tbl_karyawanMouseClicked

    private void btn_exitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_exitActionPerformed
        // TODO add your handling code here:
        System.exit(0);
    }//GEN-LAST:event_btn_exitActionPerformed

    private void txt_id_karyawanKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_id_karyawanKeyPressed
        // TODO add your handling code here:
        if(evt.getKeyCode()==evt.VK_ENTER)
            txt_nama.requestFocus();
    }//GEN-LAST:event_txt_id_karyawanKeyPressed

    private void txt_namaKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_namaKeyPressed
        // TODO add your handling code here:
        if(evt.getKeyCode()==evt.VK_ENTER)
            txt_nik.requestFocus();
    }//GEN-LAST:event_txt_namaKeyPressed

    private void txt_nohpKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_nohpKeyPressed
        // TODO add your handling code here:
        if(evt.getKeyCode()==evt.VK_ENTER)
            txt_alamat.requestFocus();
    }//GEN-LAST:event_txt_nohpKeyPressed

    private void txt_alamatKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_alamatKeyPressed
        // TODO add your handling code here:
        if(evt.getKeyCode()==evt.VK_ENTER)
            btn_save.requestFocus();
    }//GEN-LAST:event_txt_alamatKeyPressed

    private void btn_saveKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_btn_saveKeyPressed
        // TODO add your handling code here:
        boolean valid = true;
        if(evt.getKeyCode()==evt.VK_ENTER)
        if (databaru == true) { // prosess simpan atau edit
            if (txt_id_karyawan.getText().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Harap isi kolom ID karyawan");
            valid = false;
            txt_id_karyawan.requestFocusInWindow();
            }else if (txt_nama.getText().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Harap isi kolom Nama");
                valid = false;
                txt_nama.requestFocusInWindow();
            }else if (txt_nik.getText().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Harap isi kolom NIK");
                valid = false;
                txt_nik.requestFocusInWindow();
            }else if (txt_alamat.getText().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Harap isi kolom Alamat");
                valid = false;
                txt_alamat.requestFocusInWindow();
            }
            
            try {
                String jk = "";
                if (rdo_lakilaki.isSelected()){
                    jk ="Laki - laki";
                }else{
                    jk = "Perempuan";
                }
                String sql = "insert into t_karyawan values('"+txt_id_karyawan.getText()+"','"+txt_nama.getText()+"', '"+txt_nik.getText()+"', '"+jk+"', '"+cbo_jabatan.getSelectedItem()+"', '"+txt_nohp.getText()+"', '"+txt_alamat.getText()+"')";
                java.sql.Connection conn = (java.sql.Connection)aplikasi.data.karyawan.Koneksi.koneksiDB();
                java.sql.PreparedStatement pst = conn.prepareStatement(sql);
                pst.execute();

                JOptionPane.showMessageDialog(null, "Data berhasil disimpan");
            } catch (SQLException | HeadlessException e) {
                JOptionPane.showMessageDialog(null, e);
            }
        } else {
            try {
                String jk = "";
                if (rdo_lakilaki.isSelected()){
                    jk ="Laki - laki";
                }else{
                    jk = "Perempuan";
                }
                String sql = "update t_karyawan SET nama_karyawan='"+txt_nama.getText()+"', nik='"+txt_nik.getText()+"', j_kelamin='"+jk+"',jabatan='"+cbo_jabatan.getSelectedItem()+"',no_telphone='"+txt_nohp.getText()+"',alamat='"+txt_alamat.getText()+"' where id_karyawan='"+txt_id_karyawan.getText()+"'";
                java.sql.Connection conn = (java.sql.Connection)aplikasi.data.karyawan.Koneksi.koneksiDB();
                java.sql.PreparedStatement pst = conn.prepareStatement(sql);
                pst.execute();
                JOptionPane.showMessageDialog(null, "Data berhasil diperbarui");
            } catch (SQLException | HeadlessException e) {
                JOptionPane.showMessageDialog(null, e);
            }
        }
        GetData();
    
        databaru=true;
        // mengosongkan textbox
        txt_id_karyawan.setText("");
        txt_nik.setText("");
        txt_nama.setText("");
        rdo_lakilaki.setSelected(false);
        rdo_perempuan.setSelected(false);
        cbo_jabatan.setSelectedItem(null);
        txt_nohp.setText("");
        txt_alamat.setText("");
    }//GEN-LAST:event_btn_saveKeyPressed

    private void btn_clearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_clearActionPerformed
        // TODO add your handling code here:
        txt_id_karyawan.setText("");
        txt_nik.setText("");
        txt_nama.setText("");
        rdo_lakilaki.setSelected(false);
        rdo_perempuan.setSelected(false);
        cbo_jabatan.setSelectedItem(null);
        txt_nohp.setText("");
        txt_alamat.setText("");
    }//GEN-LAST:event_btn_clearActionPerformed

    private void txt_namaKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_namaKeyTyped
        // TODO add your handling code here:
        if (Character.isDigit(evt.getKeyChar())) {
            evt.consume();
            JOptionPane.showMessageDialog(null, "Harap ketik huruf abjad saja");
        }
    }//GEN-LAST:event_txt_namaKeyTyped

    private void btn_cetakActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_cetakActionPerformed
        // TODO add your handling code here:
        try{
            isiKolom(txt_id_karyawan.getText(), txt_nama.getText(), txt_nik.getText(), cbo_jabatan.getSelectedItem().toString(), txt_nohp.getText(), txt_alamat.getText());
            Statement stat = (Statement) Koneksi.koneksiDB().createStatement();
            String sql;
            ResultSet res;
            
            sql = "SELECT * FROM t_printer WHERE jenis_printer = 'Printer Label'";
            res = stat.executeQuery(sql);
            if (res.next()) {
                nm_printer = res.getString("nama_printer");
            }
            
            String label8x3 = "^XA"+
                    "^MD30"+
                    
                    //"^FO180,50^GFA,4628,4628,52,,::::P066E,O0EI6,N03C626078,M012C626064,M018C76E8E4C,L01F8E3878E1C,L01FCEJ07198,L0CFCK03B9CX0FCFF003C7E70DFEC33003C0C1F8183860C01C0E7E7E198C18,K0104M073BX0FEFF007E7E78DFEC33007E1E1FC3C3C61E01E1E7E7F198C3C,K0346M037DX0C61800626078C30C3300621618C2C3C61601E1E6063I982C,K07D4003FFI07CX0C6180060606CC30C3300603618C6C3663601B16606199B06C,K019003JF002CX0FE18007C7C6CC30C33007C331F8663663301B367C6199F066,J018E01KFE00CX0FC18001E7C66C30C33001E231F0463362301B367C6199F046,J026C07LF80C7W0C018I066062C30C33I067F198FE3167F019E6606199B8FE,J03E01MFC03BW0C01800466063C30E7300467F98CFF31E7F819E66063I98FF,J03E03FFI07FF00FW0C018607E7E61C307E3F07E6198CC330E61818C67E7F198CC3,K0207F8J0FF806W0C018607C7E61C303C3F07CC198F8330EC1818C67E7E198783,K0C1FEK03FC0E1,L03FCL0FE063,L07F003F8007F02F,L07E00C1E001F816,I07E0FC01007I0FC0E,I0FE1F8010038007E0FC,I0783F002081C003E07CJ07F81C0E1F00F01E01C0C00F8078070E33FFC061FC0E07007F801E01E06001E01E0603C0387,I0303E002040E003F07K07FE1C0E1F01F01F01C1C01FC07C070E33FFC061FF0E07007FE01F01E06001F01E0603E0387,I0187E0028206001F042J070E1C0E1F01F01F01C1C038407C071C30180061870E070070F01F01F06001F01F0603E038E,001087CK083I0F80FJ070E1C0E1F83B03B01C1C03800EC073830180061870E070070703B01F06003B01F06076039C,003F0F8K043I0F83FJ07061C0E1D83303381C1C03800CE077830180061870E070070383381F86003381F8606703BC,003F0F8K0218007C39J070E1C0E1DC3307381C1C03C01CE077030180061870E0700703873819860073819860E703B8,I010F8K0218007C07J070E1C0E1DC7307381C1C01F81CE07E030180061FE0E0700703873819C60073819C60E703F,00241FL020C007C02J07FC1C0E1CC63061C1FFC00FC18707E030180061FF0E0700703861C18C60061C18C60C383F,002E1FN0C003CL07F81C0E1CEE30E1C1FFC003E38707F030180061878E07007038E1C18E600E1C18E61C383F8,005E1FJ02I0F003E1F8I071C1C0E1CEE30E1C1C1CI0E387077030180061838E07007038E1C186600E1C18661C383B8,007A1EI0808004803E1F8I071E1C0E1C7C30FFE1C1CI0E3FF873830180061838E07007038FFE187600FFE18761FFC39C,00361E001K06C03E128I070E1C0E1C7C31FFE1C1CI0E7FF873C30180061838E07007071FFE183E01FFE183E3FFC39E,I041E002K06403E128I070E0E1C1C7C31C0F1C1C020E703C71C3018006187870E0070F1C0F183E01C0F183E381E38E,I063E002K0E601E188I07070FFC1C3831C071C1C03FC701C70E30180061FF07FE007FE1C07181E01C07181E380E387,007E3E004K0C601EL070703F01838338071C0C01F8E01C70F30180061FC01F8007F83807180E03807180E700E3878,007C3E004L0601E0C8,00503E00C1K0601E1F8,007E1E00C200100603E078,007E1E008L0603E0F,J01F00CI0180603E1D8,J01F00C008040603E188,J01F00C408I0407CK01F803IF03F003C3JF0F801F03EL01FC07C0F807C00FC003F8I0FE07FF003IF03E01F,K0F00C21J0C07CK07FE03IF83F803C7JF8F801F03EL0IF07C0F80FC01FE003FC001FE07FFE03IF83E03F,K0F80E1EJ0807CJ01IF03IF83FC03C7JF8F801F03EK01IF87C0F81F801FE003FE003FE07IF03IF83E07E,K0F806K0180F8J01IF03IF03FC03C3JF0F801F03EK03IF87C0F81F001FE003FE003FE07IF83IF03E07C,K07C0701I0300F8J03F0703EI03FE03C00F800F801F03EK07F0787C0F83E003FF003FF003FE07C1F83EI03E0F8,K07C0780400E01FK03E0103EI03FE03C00F800F801F03EK0FC0187C0F87E003DF003FF007FE07C0FC3EI03E1F8,K03E03C038F803FK03EI03EI03DF03C00F800F801F03EK0F8I07C0F8FC003CF003EF007BE07C0FC3EI03E3F,K03F01E0078003EK03EI03EI03DF03C00F800F801F03EJ01F8I07C0F8F8007CF803EF807BE07C0FC3EI03E3E,K01F80FC08I07EK03FI03EI03CF03C00F800F801F03EJ01FJ07C0F9FI078F803EF80FBE07C0FC3EI03E7C,L0FC07FEJ0FCK03FC003EI03CF83C00F800F801F03EJ01FJ07C0FBFI0787C03E780F3E07C0FC3EI03EFC,L0FE01FJ01F8K01FF003FFE03C783C00F800F801F03EJ01FJ07C0FBEI0F87C03E7C1F3E07C0F83FFE03EF8,L07FM03FM0FFC03FFE03C7C3C00F800F801F03EJ01FJ07C0FFCI0F07C03E7C1E3E07C1F83FFE03FF,J0243F8L07FM07FF03FFE03C3C3C00F800F801F03EJ01FJ07C0FFEI0F03E03E3E1E3E07IF03FFE03FF8,K0C1FEK01FE01K01FF83FFE03C3E3C00F800F801F03EJ01FJ07C0FBE001F03E03E3E3E3E07FFE03FFE03EF8,J0380FF8J07F801CK07F83EI03C1E3C00F800F801F03EJ01FJ07C0FBF001E03E03E3E3C3E07FFC03EI03EFC,J04307FEI01FF00EL01FC3EI03C1F3C00F800F801F03EJ01FJ07C0F9F801JF03E1F3C3E07FF003EI03E7E,J04C01FFE03FFE007M0FC3EI03C0F3C00F800F801F03EJ01FJ07C0F8F803JF03E1F7C3E07CI03EI03E3E,J010807LF811N07C3EI03C0FBC00F800F801F03EJ01F8I07C0F8FC03JF03E0FF83E07CI03EI03E3F,J011003KFE0128M07C3EI03C07BC00F800F801F03EK0F8I07C0F87E07JF83E0FF83E07CI03EI03E1F8,K01I07JF809AK0600F83EI03C07FC00F800FC03F03EK0FC0087C0F83E07C00F83E0FF83E07CI03EI03E0F8,K034200IF800C9K0781F83EI03C03FC00F8007E07E03EK07F0387C0F83F07C00F83E07F03E07CI03EI03E0FC,K0204N04EK07IF83IF03C03FC00F8007IFC03FFEI07IF87C0F81F8F8007C3E07F03E07CI03IF03E07E,M088M024K07IF03IF83C01FC00F8003IFC03IFI03IF87C0F80F8F8007C3E07F03E07CI03IF83E03E,L019N03L03FFC03IF83C00FC00F8I0IF003IFJ0IF07C0F80FCF8007E3E03E03E07CI03IF83E03F,L018I013Q07F003IF03C00FC0078I03FC003FFEJ03F807C0F807CFI03E3C03E01E07CI03IF03E01F,M08940120908,M01B605229,N0A4812AB,O058328C,P08324,R06,R04,,:::::::^FS" + //code untuk logo dan header
                    "^FO125, 170^GB590,0,5^FS" +  //code untuk garis tengah horizontal    
                    //"^FO490, 180^A0N,32,22^FD"+"Tgl."+" "+tglskrg+"^FS" + //LONGKAP 10 ANTAR BARIS JOKO
                    "^FO120, 205^A0N,22,22^FDNomor RM: "+idKaryawan+"^FS" +
                    "^FO120, 230^A0N,22,22^FDNama: "+nama+"^FS" +
                    "^FO120, 255^A0N,22,22^FDTgl. Lahir: "+nik+"^FS" +
                    "^FO120, 275^A0N,22,22^FDNama Obat: "+jk+"^FS" +
                    "^FO120, 300^A0N,22,22^FDED :"+jabatan+"^FS" +
                    "^FO120, 325^A0N,22,22^FDSehari: "+noHp+"^FS" +
                    "^FO120, 350^A0N,22,22^FDKet : "+alamat+"^FS" +
                    
                    "^XZ";
            
                /*penjelasan. contoh : line 870(idKaryawan): 
                ^FO adalah kode Field Origin, 120 adalah margin left
                205 adalah adalah margin top, ^A0N adalah kode untuk orientasi normal (rotasi = 0)
                22 adalah font width, 22 adalah font height
                */
            
                gelang = label8x3;
                cetakGelang(nm_printer, gelang);
        }catch(Exception e){
            System.out.println("Salah coding pada function btn_cetak" + e.getMessage());
        }
    }//GEN-LAST:event_btn_cetakActionPerformed

    private void btn_pilih_printerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_pilih_printerActionPerformed
        // TODO add your handling code here:
        new Print(null, true).setVisible(true);
    }//GEN-LAST:event_btn_pilih_printerActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(InputData.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(InputData.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(InputData.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(InputData.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new InputData().setVisible(true);
                
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_cetak;
    private javax.swing.JButton btn_clear;
    private javax.swing.JButton btn_exit;
    private javax.swing.JButton btn_hapus;
    private javax.swing.JButton btn_pilih_printer;
    private javax.swing.JButton btn_save;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JComboBox<String> cbo_jabatan;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JRadioButton rdo_lakilaki;
    private javax.swing.JRadioButton rdo_perempuan;
    private javax.swing.JTable tbl_karyawan;
    private javax.swing.JTextField txt_alamat;
    private javax.swing.JTextField txt_id_karyawan;
    private javax.swing.JTextField txt_nama;
    private javax.swing.JTextField txt_nik;
    private javax.swing.JTextField txt_nohp;
    // End of variables declaration//GEN-END:variables
}
